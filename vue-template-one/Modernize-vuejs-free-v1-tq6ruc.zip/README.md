# Free Modernize vuejs 3 based admin dashboard template Download it for free
Modernize vue3 + vite + typescript +vuetify 3 admin Template
# Chekcout the live link : https://modernize-vue3-free.netlify.app/ <a href="https://modernize-vue3-free.netlify.app/">Live Preview </a>
